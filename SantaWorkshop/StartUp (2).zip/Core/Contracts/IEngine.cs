﻿namespace SantaWorkshop.Core.Contracts
{
    using System;

    public interface IEngine
    {
        void Run();
    }
}
