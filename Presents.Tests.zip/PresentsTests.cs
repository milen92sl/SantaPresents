﻿using NUnit.Framework;

namespace Presents.Tests
{
    using System;
    using System.Collections.Generic;

    public class PresentsTests
    {
        private Bag bag;

        [SetUp]
        public void SetUp()
        {
            this.bag = new Bag();
        }

        [Test]
        public void TEST_IF_PRESENTCONSTRUCTOR_WORKS_CORRECTLY()
        {
            var expectedName = "Stick";
            double expMagic = 100;
            var present = new Present(expectedName, 100);
            var actualName = present.Name;
            var actualMagic = present.Magic;

            Assert.AreEqual(expectedName, actualName);
            Assert.AreEqual(expMagic, actualMagic);
        }

        [Test]
        public void TEST_IF_BAGCTOR_WORKS_CORRECTLY()
        {
            Bag bag = new Bag();

            Assert.IsNotNull(bag.GetPresents());
        }

        [Test]
        public void CREAT_SHOULD_THROW_EXCEPTIONWITHNULLPRESENT()
        {
            Present present = null;
            Assert.That(() => bag.Create(present),
                Throws.ArgumentNullException);
        }

        [Test]

        public void CREAT_SHOULD_THROW_EXCEPTIONWITHLIKESAME_PRESENT()
        {
            Present present = new Present("Stick", 100);
            bag.Create(present);

            Assert.That(() => bag.Create(present),
                Throws.InvalidOperationException.With.Message.EqualTo("This present already exists!"));
        }

        [Test]

        public void CREAT_SHOULD_PHYSICALLYADD_THEPRESENTS()
        {
            string name = "Stick";
            double magic = 100;

            Present p1 = new Present(name, magic);
            Present p2 = new Present(name, magic);

            bag.Create(p1);
            bag.Create(p2);

            IReadOnlyCollection<Present> exp = new List<Present>()
            {
                p1, p2
            };
            IReadOnlyCollection<Present> act = bag.GetPresents();

            CollectionAssert.AreEqual(exp, act);
        }

        [Test]

        public void CREAT_SHOULD_RETURN_CORRECT_MESSAGE()
        {
            string name = "Stick";
            double magic = 100;

            Present p1 = new Present(name, magic);

            string exp = $"Successfully added present {p1.Name}.";
            string res = bag.Create(p1);

            Assert.AreEqual(exp, res);
        }

        [Test]

        public void REMOVE_SHOULD_PHYSICALLYREMOVE_PRESENT()
        {
            string name = "Stick";
            double magic = 100;

            Present p1 = new Present(name, magic);
            Present p2 = new Present(name, magic);

            bag.Create(p1);
            bag.Create(p2);

            bool res = bag.Remove(p1);

            IReadOnlyCollection<Present> exp = new List<Present>()
            {
                p2
            };
            IReadOnlyCollection<Present> act = bag.GetPresents();

            Assert.IsTrue(res);
            CollectionAssert.AreEqual(exp, act);
        }

        [Test]

        public void TRY_REMOVING_NONEXISTINGPRESENT_SHOULDRETURN_FALSE()
        {
            string name = "Stick";
            double magic = 100;

            Present p1 = new Present(name, magic);

            bool res = bag.Remove(p1);
            Assert.IsFalse(res);
        }

        [Test]
        public void GETPRESENT_WITHLEASTMAGIC_SHOULD_WORK_CORRECTLY()
        {
            string name = "Stick";
            double magic = 100;

            Present p1 = new Present(name, magic);
            Present p2 = new Present(name, 50);
            Present exp = new Present(name, 20);

            bag.Create(p1);
            bag.Create(p2);
            bag.Create(exp);

            Present act = bag.GetPresentWithLeastMagic();

            Assert.AreEqual(exp, act);
        }

        [Test]
        public void GETPRESENT_WITHLEASTMAGIC_SHOULD_THROW_EXCEPTION()
        {
            Assert.That(()
                =>
            {
                bag.GetPresentWithLeastMagic();
            }, Throws.InvalidOperationException);
        }

        [Test]
        public void GETPRESENT_WITHLEASTMAGIC_SHOULD_RETURNCORRECT_NODUPLICATES()
        {
            string expName = "Stick";

            Present exp = new Present(expName, 100);
            Present p2 = new Present("Another", 50);
            bag.Create(exp);
            bag.Create(p2);

            Present act = bag.GetPresent(expName);

            Assert.AreEqual(exp, act);
        }

        [Test]

        public void GETPRESENT_SHOULD_RETURN_FISTPRESENT_WHENDUPLICATE()
        {
            string name = "Stick";
            double magic = 100;
            Present p1 = new Present(name, magic);
            Present p2 = new Present(name, magic);
            bag.Create(p1);
            bag.Create(p2);

            Present act = bag.GetPresent(name);

            Assert.AreEqual(p1, act);
        }

        [Test]

        public void GETPRESENT_SHOULD_RETURN_Null_WHEN_NAMENOTEXIST()
        {
            string name = "Stick";
            double magic = 100;
            Present p1 = new Present(name, magic);
            Present p2 = new Present(name, magic);
            bag.Create(p1);
            bag.Create(p2);
            string invalidName = "Non existing name";
            Present act = bag.GetPresent(invalidName);

            Assert.IsNull(act);
        }
    }

}